78r_mensural.mei

Hier gibt es nur eine Übertragung in Mensuralnotation. Maxima Notenwert ist nicht in mei-cmn vorhanden. Auch die
Mensuren sind nicht Teil von mei-cmn.
Das Vermischen der einzelnen Schemata ist zwar möglich, aber nicht empfehlenswert!
In der Codierung sind Stellen auskommentiert für einen Ansatz für eine zukunftsträchtige Codierung von den Punkten...
<!-- visuelle Codierung, inhaltlich falsch, gilt für alle folgenden artic Attribute
                              <artic artic="stacc" place="above"/>  -->
                                        <!-- zukunftsträchtige Codierung, entweder als ligature mit zwei noten oder einzelne Note?
                              <accid accid="1qf" form="dot" place="above-left"/> -->