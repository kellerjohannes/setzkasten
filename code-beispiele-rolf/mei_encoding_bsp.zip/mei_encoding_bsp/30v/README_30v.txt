Bemerkungen:
30v_mei_CMN_section.mei
moderne Notation und Schlüsseln inklusive Taktelementen (<measure></measure>).

Das Beispiel ist in zwei <section> Elemente unterteilt. 1. <section> mit zwei Stimmen, 2. <section> mit drei Stimmen.
Die Stimmen werden im <scoreDef>... </scoreDef> definiert.
Rendering funktioniert mittels Verovio nicht wirklich!

30v_mei-CMN_mdiv
moderne Notation und Schlüsseln inklusive Taktelementen (<measure></measure>).

Das Beispiel ist zusätzlich in zwei <mdiv> Elemente unterteilt. 1. <mdiv> mit zwei Stimmen, 2. <mdiv> mit drei Stimmen.
mdiv ist eine gröbere Unterteilung als section. mdiv Elemente können in Verovio nur gesondert gerendert werden
--> Das Rendering ist bei unterschiedlicher Anzahl Stimmen sehr kompliziert. 

30v_mei-mensural_section.mei
mensurale Notation und Schlüssel, Striche als Taktstriche (<barline/>).

Das Beispiel ist in zwei <section> Elemente unterteilt. 1. <section> mit zwei Stimmen, 2. <section> mit drei Stimmen.
Die Stimmen werden im <scoreDef>... </scoreDef> definiert.
Rendering funktioniert mittels Verovio nicht wirklich!

30v_mei-mensural_mdiv.mei
mensurale Notation und Schlüssel, Striche als Taktstriche (<barline/>).

Das Beispiel ist zusätzlich in zwei <mdiv> Elemente unterteilt. 1. <mdiv> mit zwei Stimmen, 2. <mdiv> mit drei Stimmen.
mdiv ist eine gröbere Unterteilung als section. mdiv Elemente können in Verovio nur gesondert gerendert werden
--> Das Rendering ist bei unterschiedlicher Anzahl Stimmen sehr kompliziert. 





