Bemerkungen:
17v_CMN.mei
moderne Notation und Schlüsseln inklusive Taktelementen (<measure></measure>).

17v_mensural.mei
mensurale Notation und Schlüssel, Striche als Taktstriche (<barline/>).
Ligaturen werden in der Codierung um die betreffenden Noten gewrappt. (Momentan noch auskommentiert <!-- -->)





