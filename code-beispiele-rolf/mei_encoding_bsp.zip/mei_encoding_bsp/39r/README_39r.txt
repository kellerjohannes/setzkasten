Bemerkungen:
39r_CMN_4voices.mei
Das Beispiel enthält für jede Stimme einen <staffDef> Container und ein <staff>Container

39r_CMN_alternativ.mei
Wie im skizzierten Beispiel:
Das Beispiel enthält für zwei Stimmen (Soprano & Alto) und (Tenore & Basso) je eine Stimme mit zwei <layer>.
